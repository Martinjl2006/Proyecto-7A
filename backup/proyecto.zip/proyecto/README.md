proyecto_2025

Nombre del proyecto:LeyendAR

Es un mapa interactivo con los mitos y leyendas de la republica Argentina 

Integrantes:Martin Lage, Zoe Bree, Juan Cruz, Jeremias Lorenzo, Joaquin Gutti
