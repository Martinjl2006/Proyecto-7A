<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario está logueado
if (!isset($_SESSION["username"]) || !isset($_SESSION["id_usuario"])) {
    header("Location: login.php"); // o tu página de login
    exit();
}
?>